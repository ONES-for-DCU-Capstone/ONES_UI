package com.example.oneshome

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ActivityPostView : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post_view)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_post_view, menu)
        val inflater: MenuInflater = menuInflater

        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.post_view_btn_report -> {
                Toast.makeText(this, "게시글이 신고되었습니다.", Toast.LENGTH_SHORT).show()
                return true
            }

            else -> return false
        }
    }
}