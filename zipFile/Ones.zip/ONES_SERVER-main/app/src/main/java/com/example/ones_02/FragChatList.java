package com.example.ones_02;

import android.app.Activity;

public class FragChatList extends Activity {
}
